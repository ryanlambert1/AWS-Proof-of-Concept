//Ryan Lambert (c3397980) SENG4400 Assignment 2 Get Reminder function

const AWS = require("aws-sdk");
const db = new AWS.DynamoDB.DocumentClient();
const TABLE = "Reminders";

exports.handler = async (event) => 
{
  const { userID, title, dueDate } = JSON.parse(event.body);

  const params = 
  {
    TableName: TABLE,
    TableName: TABLE,
    Item: {
      userID: userID, 
      title,
      dueDate,
    }
  };

  try 
  {
    await db.get(params).promise();
    return {
      statusCode: 201,
      body: JSON.stringify({ message: "Reminder retrieved." }),
    };
  }  catch (error)
     {
       return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error retrieving reminder", error }),
    };
  }
};
